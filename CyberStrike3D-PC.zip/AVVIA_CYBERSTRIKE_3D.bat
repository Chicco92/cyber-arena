@echo off
title Avvio CyberStrike 3D
echo ==============================================
echo   CYBERSTRIKE 3D - Galaxy & Prestige Edition
echo   Avvio in modalita' Desktop Standalone...
echo ==============================================
start msedge --app="%~dp0CyberStrike3D.html" --start-fullscreen
if errorlevel 1 (
    start chrome --app="%~dp0CyberStrike3D.html" --start-fullscreen
)
if errorlevel 1 (
    start "" "%~dp0CyberStrike3D.html"
)
exit
